copy .\sdk\*.dll %windir%\system32\
copy .\sdk\*.dll %windir%\SysWOW64
regsvr32 %windir%\system32\zkemkeeper.dll
regsvr32 %windir%\SysWOW64\zkemkeeper.dll